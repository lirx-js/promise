/**
 * @deprecated
 */
export type IPromiseLikeOrValue<GValue> =
  | PromiseLike<GValue>
  | GValue
  ;
