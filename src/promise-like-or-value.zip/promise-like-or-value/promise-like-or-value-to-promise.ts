import { IPromiseLikeOrValue } from './promise-like-or-value.type';

/**
 * @deprecated
 */
export function promiseLikeOrValueToPromise<GValue>(
  input: IPromiseLikeOrValue<GValue>,
): Promise<GValue> {
  return new Promise<GValue>((
    resolve: (value: IPromiseLikeOrValue<GValue>) => void,
  ): void => {
    resolve(input);
  });
}
