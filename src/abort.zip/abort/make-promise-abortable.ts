import { IAbortablePromiseOptions } from './abortable-promise-options.type';
import { createAbortablePromise, IAbortablePromiseResolveFunction } from './create-abortable-promise';

/**
 * Use only if you cannot use createAbortablePromise
 * @see createAbortablePromise
 */
export function makePromiseAbortable<GValue>(
  promise: Promise<GValue>,
  options?: IAbortablePromiseOptions,
): Promise<GValue> {
  return createAbortablePromise<GValue>((
    resolve: IAbortablePromiseResolveFunction<GValue>,
  ): void => {
    resolve(promise);
  }, options);
}
