import { createAbortError } from '../../errors/abort-error/create-abort-error';
import { createEventListener } from '../../event-listener/functions/create-event-listener';
import { IPromiseLikeOrValue } from '../promise-like-or-value/promise-like-or-value.type';
import { IAbortablePromiseOptions } from './abortable-promise-options.type';

/** TYPES **/

export interface IAbortablePromiseResolveFunction<GValue> {
  (
    value: IPromiseLikeOrValue<GValue>,
  ): void;
}

export interface IAbortablePromiseRejectFunction {
  (
    reason?: any,
  ): void;
}

export interface IAbortablePromiseOnAbortCallbackFunction {
  (
    event: Event,
  ): void;
}

export interface IAbortablePromiseOnAbortUnsubscribeFunction {
  (): void;
}

export interface IAbortablePromiseOnAbortFunction {
  (
    callback: IAbortablePromiseOnAbortCallbackFunction,
  ): IAbortablePromiseOnAbortUnsubscribeFunction;
}

export interface ICreateAbortablePromiseFactoryFunction<GValue> {
  (
    resolve: IAbortablePromiseResolveFunction<GValue>,
    reject: IAbortablePromiseRejectFunction,
    abort$: IAbortablePromiseOnAbortFunction,
  ): void;
}

/** FUNCTION **/

const empty = () => (() => {
});

/**
 * Creates a Promise with an abortable context
 */
export function createAbortablePromise<GValue>(
  factory: ICreateAbortablePromiseFactoryFunction<GValue>,
  {
    signal,
  }: IAbortablePromiseOptions = {},
): Promise<GValue> {
  return new Promise<GValue>((
    resolve: (value: IPromiseLikeOrValue<GValue>) => void,
    reject: (reason?: any) => void,
  ): void => {
    if (signal?.aborted) {
      reject(createAbortError({ signal }));
    } else {
      if (signal === void 0) {
        factory(resolve, reject, empty);
      } else {
        const end = () => {
          unsubscribeOfAbort();
        };

        const _resolve = (
          value: IPromiseLikeOrValue<GValue>,
        ): void => {
          end();
          resolve(value);
        };

        const _reject = (
          reason?: any,
        ): void => {
          end();
          reject(reason);
        };

        const onAbort = () => {
          _reject(createAbortError({ signal }));
        };

        const abort$ = (
          callback: IAbortablePromiseOnAbortCallbackFunction,
        ): IAbortablePromiseOnAbortUnsubscribeFunction => {
          return createEventListener<'abort', Event>(
            signal,
            'abort',
            callback,
            { once: true },
          );
        };

        const unsubscribeOfAbort = abort$(onAbort);

        try {
          factory(_resolve, _reject, abort$);
        } catch (error: unknown) {
          _reject(error);
        }
      }
    }
  });
}
