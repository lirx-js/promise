import { IPromiseFactory } from '../../factory/promise-factory.type';
import { IAbortablePromiseOptions } from '../abortable-promise-options.type';
import { callSelfAbortablePromiseFactory, ICallSelfAbortablePromiseFactoryOptions } from '../call-self-abortable-promise-factory';
import { makePromiseAbortable } from '../make-promise-abortable';

export function abortablePromiseFactoryAll<GValue>(
  promiseFactories: Iterable<IPromiseFactory<GValue>>,
  options?: IAbortablePromiseOptions,
): Promise<Awaited<GValue>[]>;
export function abortablePromiseFactoryAll<GItems extends readonly IPromiseFactory<unknown>[] | []>(
  promiseFactories: GItems,
  options?: IAbortablePromiseOptions,
): Promise<{ -readonly [P in keyof GItems]: Awaited<ReturnType<GItems[P]>> }>;
export function abortablePromiseFactoryAll<GValue>(
  promiseFactories: Iterable<IPromiseFactory<GValue>>,
  options?: IAbortablePromiseOptions,
): Promise<Awaited<GValue>[]> {
  type TValue = Awaited<GValue>;

  return callSelfAbortablePromiseFactory<TValue[]>((
    options: ICallSelfAbortablePromiseFactoryOptions,
  ): Promise<TValue[]> => {
    return makePromiseAbortable<TValue[]>(
      Promise.all<GValue>(
        Array.from<IPromiseFactory<GValue>, Promise<GValue>>(
          promiseFactories,
          (
            factory: IPromiseFactory<GValue>,
          ): Promise<GValue> => {
            return factory(options);
          },
        ),
      ),
      options,
    );
  }, options);
}

// export function abortablePromiseFactoryAll<GValue>(
//   promiseFactories: Iterable<IPromiseFactory<GValue>>,
//   options?: IAbortablePromiseOptions,
// ): Promise<GValue[]> {
//   return createSelfAbortablePromiseFactory<GValue[]>((
//     options: ICreateSelfAbortablePromiseFactoryOptions,
//   ): Promise<GValue[]> => {
//     // all<T extends readonly unknown[] | []>(values: T): Promise<{ -readonly [P in keyof T]: Awaited<T[P]> }>;
//     return makePromiseAbortable<GValue[]>(
//       Promise.all(
//         Array.from(
//           promiseFactories,
//           (
//             factory: IPromiseFactory<GValue>,
//           ): Promise<GValue> => {
//             return factory(options);
//           },
//         ),
//       ),
//     );
//   }, options);
// }

// export function abortablePromiseFactoryAll<GValue>(
//   promiseFactories: Iterable<IPromiseFactory<GValue>>,
//   options: IAbortablePromiseOptions = {},
// ): Promise<GValue> {
//   return createAbortablePromise<GValue>((
//     resolve: IAbortablePromiseResolveFunction<GValue>,
//     reject: IAbortablePromiseRejectFunction,
//   ): void => {
//     const _controller: AbortController = createAbortControllerFromAbortSignals((options.signal === void 0) ? [] : [
//       options.signal,
//     ]);
//     const _signal = _controller.signal;
//
//     let values!: GValue[];
//     let length: number = 0;
//
//     const iterator: Iterator<IPromiseFactory<GValue>> = promiseFactories[Symbol.iterator]();
//     let result: IteratorResult<IPromiseFactory<GValue>>;
//     while (!(result = iterator.next()).done) {
//       length++;
//       result.value({
//         ...options,
//         signal: _signal,
//       })
//         .finally((): void => {
//
//         })
//         .then(
//           () => {
//
//           },
//           () => {
//             _controller.abort();
//           },
//         );
//     }
//     values = new Array<GValue>(length);
//   }, options);
// }
