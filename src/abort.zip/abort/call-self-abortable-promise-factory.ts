import { IAbortablePromiseOptions } from './abortable-promise-options.type';
import { createAbortControllerFromAbortSignal } from './controller/create-abort-controller-from-abort-signal';

export type ICallSelfAbortablePromiseFactoryOptions<GOptions extends IAbortablePromiseOptions = IAbortablePromiseOptions> =
  Omit<GOptions, 'signal'>
  & Required<Pick<GOptions, 'signal'>>
  ;

export interface ICallSelfAbortablePromiseFactory<GValue, GOptions extends IAbortablePromiseOptions = IAbortablePromiseOptions> {
  (
    options: ICallSelfAbortablePromiseFactoryOptions<GOptions>,
  ): Promise<GValue>;
}

export function callSelfAbortablePromiseFactory<GValue, GOptions extends IAbortablePromiseOptions = IAbortablePromiseOptions>(
  factory: ICallSelfAbortablePromiseFactory<GValue, GOptions>,
  options?: GOptions,
): Promise<GValue> {
  const controller: AbortController = (options?.signal === void 0)
    ? new AbortController()
    : createAbortControllerFromAbortSignal(options.signal);

  return factory({
    ...options,
    signal: controller.signal,
  } as ICallSelfAbortablePromiseFactoryOptions<GOptions>)
    .finally((): void => {
      controller.abort();
    });
}


/*---------*/

// export function callAndMakeSelfAbortablePromiseFactory<GValue, GOptions extends IAbortablePromiseOptions = IAbortablePromiseOptions>(
//   factory: ICallSelfAbortablePromiseFactory<GValue, GOptions>,
//   options?: GOptions,
// ): Promise<GValue> {
//   const controller: AbortController = (options?.signal === void 0)
//     ? new AbortController()
//     : createAbortControllerFromAbortSignal(options.signal);
//
//   return factory({
//     ...options,
//     signal: controller.signal,
//   } as ICallSelfAbortablePromiseFactoryOptions<GOptions>)
//     .finally((): void => {
//       controller.abort();
//     });
// }
