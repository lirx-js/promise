export interface IAbortablePromiseOptions {
  signal?: AbortSignal;
}


// export type IRequiredAbortablePromiseOptions = Required<IAbortablePromiseOptions>;
