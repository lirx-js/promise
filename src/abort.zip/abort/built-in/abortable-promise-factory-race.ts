import { IPromiseFactory } from '../../factory/promise-factory.type';
import { IAbortablePromiseOptions } from '../abortable-promise-options.type';
import { createAbortControllerFromAbortSignals } from '../controller/create-abort-controller-from-abort-signals';
import { createAbortablePromise, IAbortablePromiseRejectFunction, IAbortablePromiseResolveFunction } from '../create-abortable-promise';

export function abortablePromiseFactoryRace<GValue>(
  promiseFactories: Iterable<IPromiseFactory<GValue>>,
  options: IAbortablePromiseOptions = {},
): Promise<GValue> {
  return createAbortablePromise<GValue>((
    resolve: IAbortablePromiseResolveFunction<GValue>,
    reject: IAbortablePromiseRejectFunction,
  ): void => {
    const _controller: AbortController = createAbortControllerFromAbortSignals((options.signal === void 0) ? [] : [
      options.signal,
    ]);
    const _signal = _controller.signal;

    const iterator: Iterator<IPromiseFactory<GValue>> = promiseFactories[Symbol.iterator]();
    let result: IteratorResult<IPromiseFactory<GValue>>;
    while (!(result = iterator.next()).done) {
      result.value({
        ...options,
        signal: _signal,
      })
        .finally((): void => {
          _controller.abort();
        })
        .then(resolve, reject);
    }
  }, options);
}
